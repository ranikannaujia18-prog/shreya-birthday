SHREYA COMPLETE BIRTHDAY WEBSITE

1. Extract this ZIP.
2. Open index.html in Chrome/Edge.
3. The four supplied photos are already inside images/.
4. The selected YouTube song is embedded in the page.
5. Click "Open My Surprise" and then the Music button if the browser blocks autoplay.

Files:
- index.html
- style.css
- script.js
- images/photo1.jpg ... photo4.jpg

The song is played through YouTube's embedded player; the audio file itself is not downloaded.
